---
name: ritchie
description: Write, explain, check, debug, and teach Ritchie programs from the bundled public language capsule. Use for Ritchie coding questions, generated examples, exercises, diagnostics, and interactive lessons. Do not use for compiler implementation, conformance development, or language design.
---

# Ritchie

Use this skill for user-facing Ritchie programming and learning. Base language
claims on the bundled language capsule, and settle any doubt about what the
current compiler accepts or prints with the observed references, which are
generated from the compiler source revision named in each file's header. Do
not inspect an adjacent language repository, compiler source, feature records,
implementation notes, or test fixtures to fill a gap.

## Route the request

- Read [references/language.md](references/language.md) before writing,
  correcting, or explaining Ritchie code. It is the compact capsule and the
  default source for every language claim.
- Open the observed references only for a specific question, and search
  them rather than reading them whole:
  [observed/build.md](references/observed/build.md) for the exact built-in
  signatures, operator table, excluded and reserved forms, and diagnostic
  reason codes; [observed/programs.md](references/observed/programs.md) for a
  program that prints what a form produces;
  [observed/rejections.md](references/observed/rejections.md) for a
  diagnostic's meaning; [observed/handoffs.md](references/observed/handoffs.md)
  for the detailed behavior contract of one facility.
  `observed/capsule-gaps.md` is a maintenance report for refreshing the
  capsule and is not a language source.
- Read [references/teaching.md](references/teaching.md) for lessons, exercises,
  quizzes, or stepwise explanations.
- Read [references/compiler-service.md](references/compiler-service.md) before
  submitting code or interpreting a service response.

If a requested facility is absent from the bundled references, say that the
current public skill does not document it. Offer a documented alternative when
one exists. Do not infer Ritchie behavior from Go or another language.

## Programming responses

Prefer the smallest program that answers the request. Explain unfamiliar
Ritchie constructs and material semantic details; omit generic programming
commentary the user does not need.

Generated examples are illustrative rather than canonical. When runnable
correctness matters, check the final source with the compiler service. Report
the service outcome accurately and do not describe unchecked code as tested.
Compiler acceptance establishes compatibility with the reported compiler
revision, while the bundled capsule remains the source for language
explanations.

If the service rejects a documented construct as `limit.unsupported-syntax`,
identify a compiler-revision compatibility gap. Do not remove the documented
construct from an explanation merely to match an older deployed compiler.

Submitting user-provided source to the service is an external data transfer.
Do so only when the user asks to run, compile, test, or debug that source. Code
created for the user may be checked when doing so materially improves the
answer and contains no sensitive information.

## Service use

Pass source on standard input:

```sh
python3 <skill-directory>/scripts/run_ritchie.py -
```

The client emits the complete JSON response. Treat `stderr` as program output
when `log` is used, and treat `diagnostics` as compiler records. A valid service
response can describe rejection or runtime failure; distinguish that from an
HTTP, transport, or malformed-response failure.

Use at most a few focused submissions for one answer. Stop after the same
service or transport failure repeats, and continue with a clearly marked
unchecked explanation when useful.

If the compilation command cannot run because the environment blocks Python,
subprocesses, or network access, do not present that as a compiler result.
Mark the source as unchecked and suggest that the user run it in the
[Ritchie playground](https://ritchie.dev/playground/) instead.

## Public-content boundary

The programs in `references/observed/programs.md` and
`references/observed/rejections.md` are observations, not tutorials; write
fresh examples for lessons. Do not expose operational identifiers, repository
history, private design material, implementation details, or internal test
expectations. Keep generated learning content within the facilities documented
by the bundled references.
