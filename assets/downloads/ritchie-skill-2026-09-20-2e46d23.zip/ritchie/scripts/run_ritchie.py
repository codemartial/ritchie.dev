#!/usr/bin/env python3
"""Submit one Ritchie source file or stdin to the public playground service."""

from __future__ import annotations

import argparse
import json
import sys
import urllib.error
import urllib.request


DEFAULT_URL = "https://0ocstfngy8.execute-api.ap-southeast-2.amazonaws.com/run"
MAX_SOURCE_BYTES = 16 * 1024
MAX_RESPONSE_BYTES = 512 * 1024
OUTCOMES = {
    "completed",
    "rejected",
    "runtime_error",
    "timed_out",
    "output_limit",
    "compiler_failure",
}


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("source", nargs="?", default="-", help="source file, or - for stdin")
    parser.add_argument("--url", default=DEFAULT_URL, help="complete service /run URL")
    parser.add_argument("--timeout", type=float, default=10.0, help="HTTP timeout in seconds")
    parser.add_argument("--compact", action="store_true", help="emit compact JSON")
    return parser.parse_args()


def read_source(path: str) -> str:
    try:
        if path == "-":
            data = sys.stdin.buffer.read()
        else:
            with open(path, "rb") as source_file:
                data = source_file.read()
    except OSError as error:
        raise ValueError(f"cannot read source: {error}") from error
    if len(data) > MAX_SOURCE_BYTES:
        raise ValueError(f"source exceeds {MAX_SOURCE_BYTES} bytes")
    try:
        return data.decode("utf-8")
    except UnicodeDecodeError as error:
        raise ValueError("source is not valid UTF-8") from error


def request_run(url: str, source: str, timeout: float) -> dict[str, object]:
    payload = json.dumps({"source": source}, ensure_ascii=False).encode("utf-8")
    request = urllib.request.Request(
        url,
        data=payload,
        headers={"content-type": "application/json", "user-agent": "ritchie-skill/1"},
        method="POST",
    )
    try:
        with urllib.request.urlopen(request, timeout=timeout) as response:
            body = response.read(MAX_RESPONSE_BYTES + 1)
    except urllib.error.HTTPError as error:
        detail = error.read(4096).decode("utf-8", "replace")
        raise RuntimeError(f"service returned HTTP {error.code}: {detail}") from error
    except urllib.error.URLError as error:
        raise RuntimeError(f"service request failed: {error.reason}") from error
    if len(body) > MAX_RESPONSE_BYTES:
        raise RuntimeError("service response exceeds client limit")
    try:
        result = json.loads(body)
    except (UnicodeDecodeError, json.JSONDecodeError) as error:
        raise RuntimeError("service returned malformed JSON") from error
    validate_result(result)
    return result


def validate_result(value: object) -> None:
    if not isinstance(value, dict):
        raise RuntimeError("service response is not an object")
    checks = {
        "outcome": str,
        "exitCode": int,
        "stdout": str,
        "stderr": str,
        "diagnostics": list,
        "durationMs": int,
        "compilerRevision": str,
    }
    for field, expected in checks.items():
        if type(value.get(field)) is not expected:
            raise RuntimeError(f"service response has invalid {field}")
    if value["outcome"] not in OUTCOMES:
        raise RuntimeError("service response has unknown outcome")


def main() -> int:
    args = parse_args()
    if args.timeout <= 0:
        print("timeout must be positive", file=sys.stderr)
        return 2
    try:
        source = read_source(args.source)
        result = request_run(args.url, source, args.timeout)
    except (ValueError, RuntimeError) as error:
        print(error, file=sys.stderr)
        return 1
    if args.compact:
        json.dump(result, sys.stdout, ensure_ascii=False, separators=(",", ":"))
    else:
        json.dump(result, sys.stdout, ensure_ascii=False, indent=2)
    sys.stdout.write("\n")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
