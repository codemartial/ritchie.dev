# Teaching Ritchie

Generate learning material for the learner's stated goal and current level;
the skill carries no fixed course or canonical example set.

For an interactive lesson:

1. Establish the learner's goal from the conversation. If their level is not
   apparent, begin with a small task and adjust from their response.
2. Introduce one main Ritchie idea at a time using a short generated program or
   fragment.
3. Explain the Ritchie-specific syntax and behavior, then ask the learner to
   predict, complete, or modify something small.
4. Give a hint before a full solution unless the learner asks for the answer.
5. Compile generated runnable material when the service is available. Turn a
   diagnostic into a focused explanation rather than merely rewriting the code.
6. Recap the concept and connect it to one documented next step.

Keep exercises within `references/language.md`. Label generated examples as
examples, not official idioms. Do not derive lesson content from conformance
cases: those cases target compiler distinctions and may be poor teaching
material.

When the learner asks for a full progression, build it incrementally from:

- `main` and `log`
- typed bindings and expressions
- functions and results
- conditions and loops
- String and arrays
- structs and methods
- dictionaries and nullable values
- errors and recovery

Reorder or omit topics to match the learner's goal. Use retrieval practice and
small modifications more often than long lectures.
