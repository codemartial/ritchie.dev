# Ritchie language capsule

This is a compact programming guide derived only from the approved public
conformance gate. It records currently documented facilities rather than the
entire language; a construct absent here is undocumented by this skill.

## Program and source basics

- Ritchie source files use the `.ri` extension.
- An executable source has at most one root `main()` with no parameters and no
  result. Reaching the end completes successfully.
- Layout: newlines end statements and declarations, semicolons separate
  statements on one line, parentheses and square brackets suppress newline
  termination, braces retain it, and a trailing backslash continues a statement.
- Line comments start with `//`. Block comments use `/* ... */` and may nest.
- Names are case-sensitive. Ordinary values and functions start with lowercase
  or `_`; constants use uppercase names; types start uppercase and contain a
  lowercase letter.
- Use `and`, `or`, and `not` for Boolean logic. `&&`, `||`, prefix `!`, `++`,
  and `--` are excluded.
- Operators bind from tightest to loosest: member access, call, and index;
  unary `-`; `*`, `/`, `%`; `+`, `-`; `??`; `<`, `<=`, `>`, `>=`; `==`, `!=`;
  `not`; `and`; `or`; the ternary `c ? a : b`; assignment, a statement;
  `handle`. Chains such as `a < b < c`, a ternary inside a ternary or beside
  `??`, and a binary operator ending a line are rejected.
- `log(value)` writes one default-form value and a line break to standard
  error and returns no value.

## Bindings, functions, and calls

Bindings carry a written type:

```ritchie
Int total = 0
Int left, right = 1, 2
Int pending
Int LIMIT = 42
```

A lowercase name is mutable. An uppercase binding is a compile-time constant
and requires a constant initializer. A declaration-only binding must be
assigned on every path before it is read.

Free functions are module-private and declaration order does not affect calls.
They have zero, one, or several ordered results:

```ritchie
double(Int value) -> Int { return value * 2 }
pair() -> (Int, Bool) { return 1, true }
```

Positional arguments bind in parameter order. Named arguments bind by name and
evaluate in written order; do not mix positional and named forms. Arguments
evaluate once from left to right. `return` ends a routine; a routine with a
result must return on every completing path.

A method is declared with its receiver type:

```ritchie
Counter.increment(Int amount) {
    self.value += amount
}
```

Using `self` makes it an instance method. A method with no `self` use is called
through its type. An instance call on a mutable variable, field, array element,
or dictionary entry can update that place. Names beginning `_` are private to
the declaring module.

## Scalar values and operators

- `Bool` has `true` and `false`, equality, `not`, short-circuiting `and` and
  `or`.
- `Int8`, `Int16`, `Int32`, and `Int64` are signed integers; `Int` is `Int64`.
  Literals may be decimal or use `0x`, `0o`, and `0b`. Narrower signed integers
  widen implicitly. Runtime integer arithmetic wraps at its width; constant
  arithmetic is range-checked.
- Integer `/` truncates toward zero. `%` has the dividend's sign. Runtime zero
  division raises `DivisionByZero!`.
- `Float` is binary64 and supports `+`, `-`, `*`, `/`, `%`, comparisons, IEEE
  infinities, NaN, and signed zero at runtime. Integer values do not implicitly
  become Float.
- `Decimal` is decimal128: 34 significant digits, round half to even once per
  written operator, and a retained quantum, so `1.20 + 3.400` displays as
  `4.600`. Fractional literals use Decimal where required and Float otherwise.
  Decimal admits arithmetic, equality, ordering, `abs`, `min`, and `max`.
  `Decimal.fromInt` is exact; `Decimal.fromFloat` rounds the actual binary64
  value and rejects nonfinite values. `Float.fromDecimal` rounds to binary64
  and rejects overflow. Runtime arithmetic failures raise `DivisionByZero!`
  or `OutOfRange!`; known constant failures are rejected.
- `Byte` represents 0 through 255. Use `Byte.fromInt` and `Int.fromByte` for
  conversion. `abs`, `min`, and `max` apply to any one numeric type.
- `Date` is Gregorian civil date; `Time` is nanosecond civil time of day.
- `DateTime` is an instant with a retained fixed offset; `Duration` is a signed
  physical span with adaptive nanosecond or millisecond resolution.

```ritchie
main() {
    Decimal price = 1.20
    Decimal rate = 3.400
    log(price * rate)
    log(7 / 2)
    log(-7 % 3)
}
```

```output
4.08000
3
-1
```

## Conditions and loops

Conditions do not use statement-level parentheses:

```ritchie
if ready {
    work()
} else if retry {
    recover()
} else {
    stop()
}
```

`for { ... }` repeats without a condition. `for condition { ... }` checks a
Bool before each iteration. `break` and `continue` target the innermost loop;
labelled forms name an enclosing labelled loop.

Iterate integer ranges and collections with an inferred binder:

```ritchie
for i in range(3) { ... }          // 0, 1, 2
for i in range(2, 5) { ... }       // 2, 3, 4
for i in range(7, 0, -3) { ... }   // 7, 4, 1
for item in values { ... }
for key, value in dictionary { ... }
```

Range bounds are excluded. Array iteration proceeds by increasing index.
Dictionary iteration order is unspecified.

## String and bytes

- `String` contains valid UTF-8. Quoted strings support escapes; backtick
  strings are raw and may span lines.
- Formatted strings use `f"...{expression}..."`; doubled braces produce literal
  braces.
- `Byte[]` literals use `b"..."`; they may contain arbitrary bytes and add
  `\xHH` escapes. `Byte[].fromString` encodes UTF-8 and `String.fromBytes`
  validates UTF-8.
- String counts, searches, and slice bounds use UTF-8 byte positions. String
  slicing must also use scalar boundaries; `s.isRuneBoundary(position)`
  reports whether a byte position begins a scalar. Single indexing of String
  is not available.
- String built-ins include `count`, `isEmpty`, `contains`, `startsWith`,
  `endsWith`, `indexOf`, `toUpper`, `toLower`, `trim`, `replace`, `split`, and
  `join`.
- String `+` and `+=` are not available; use formatted strings or `join`.

## Structs

A struct lists typed fields. Construction uses field values in braces:

```ritchie
Point {
    Int x
    Int y = 0
}

Point point = Point { x: 3 }
point.y = 4
```

Fields with defaults may be omitted; other fields are required. Values are
owned: ordinary binding, argument, return, field, and collection transfers
produce independently mutable aggregate values.

A struct may refer to itself only through a nullable field, such as
`Tree? left = none`, or through an array or dictionary of itself. Such values
are finite, copy independently at every depth, and display in full.

## Arrays

`T[]` is a dynamic array. `T[N]` is a fixed array whose count is part of its
type. Literals use `[a, b, c]`; an empty literal needs an array context.

```ritchie
Int[] values = [1, 2, 3]
Int[3] triple = [1, 2, 3]
Int[] empty = []
```

Indexing is zero-based and may raise `OutOfRange!`. Slices are half-open:
`xs[lo:hi]`, `xs[lo:]`, `xs[:hi]`, and `xs[:]`. Slicing either array form
returns an independent dynamic array.

Common operations:

- `count(xs)`, `contains(xs, value)`, and `indexOf(xs, value)`
- `first(xs)` and `last(xs)`, each returning a nullable result
- `append(xs, value)`, `insert(xs, index, value)`, and `removeAt(xs, index)` for
  dynamic arrays
- `concat(xs, ys)` for matching dynamic arrays
- `reverse(xs)` and `sort(xs)` for applicable dynamic or fixed arrays
- `fill(value, count)` with result type supplied by context when needed

Transforming operations return independent arrays and leave inputs unchanged.
Element assignment updates a mutable array place.

## Dictionaries

`[K: V]` is a dynamic dictionary. Literals use `[key: value]`; `[:]` requires
a dictionary context. A later equal key replaces an earlier entry.

```ritchie
[String: Int] scores = ["Ada": 10, "Lin": 12]
scores["Ada"] = 13
```

`d[k]` returns `V` or raises `MissingKey!`. `d.get(k)` returns `V?`. Other
operations include `count`, `has`, `keys`, `values`, `remove`, `zip`, and
`unzip`. `keys`, `values`, display, and iteration have unspecified order;
within one `unzip` result the two arrays remain positionally aligned.

## Nullable values

`T?` is either a present `T` or `none`. `none` needs a nullable context:

```ritchie
Int? score = none
Int resolved = score ?? 0
score ??= 7
```

A value of `T` can be used where `T?` is required. Test a nullable name directly
or compare it with `none` to establish presence before using the payload. A
present zero, false, or empty value remains present. `??` evaluates its fallback
only for absence. `??=` requires a mutable nullable target.

## Errors and recovery

Error types end in `!` and may have typed fields:

```ritchie
Missing! { String item }
```

Returning an error value raises it. A `handle` protects a statement, block, or
loop. Every handler has at least one arm; a single arm may omit its list braces
when its pattern follows `handle` on the same line. Multiple arms use braces.
An arm can replace results, return, break, continue, raise, or propagate; its
valid results depend on the exact failed operation it can select.

```ritchie
Missing! { String item }

find(String item) -> Int {
    return Missing! { item: item }
}

main() {
    Int found = find("key") handle { Missing! e => 0 }
    log(found)
    log(find("again"))
    log("unreached")
}
```

```output
0
Missing! { item: "again" }
  at main
  raised by find(item: "again")
```

An error that escapes `main` ends the program with exit status 1 after one
report: the error value with its fields, `at` the location, `raised by` the
raising routine with the argument text captured at the raise, and `via` lines
for each propagation step retained in the error's `history`.

Built-in failures include `DivisionByZero!`, `OutOfRange!`, `Malformed!`,
`InvalidStringBoundary!`, `MissingKey!`, and `LengthMismatch!` where their
documented operations apply.

## Type aliases and modules

An alias uses `Alias = Target` and denotes the target type rather than a wrapper.
Aliases are module-private. Multi-module projects use a project mapping and
qualified access with `module::Member`; the anonymous compiler service accepts
one source string, so generated service examples should remain single-file.

## Running programs

`rcrun program.ri` builds and runs a program with the local Go toolchain;
`rcrun -` reads it from standard input, and the compiler service runs the same
compiler. `log` output arrives on standard error. A completed `main` exits 0;
a rejected program exits 1 with diagnostics and starts nothing; an escaping
error exits 1 after its report. `--no-traceback` omits only the `via` lines.
