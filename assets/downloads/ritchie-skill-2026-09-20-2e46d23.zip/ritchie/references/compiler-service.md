# Ritchie compiler service

The public playground provides an anonymous, single-file execution service:

```text
POST https://0ocstfngy8.execute-api.ap-southeast-2.amazonaws.com/run
Content-Type: application/json
```

Request:

```json
{"source":"main() {\n    log(42)\n}\n"}
```

The object must contain exactly one `source` string. Source must be valid UTF-8
and at most 16 KiB.

A language outcome uses HTTP 200 and contains:

```json
{
  "outcome": "completed",
  "exitCode": 0,
  "stdout": "",
  "stderr": "42\n",
  "diagnostics": [],
  "durationMs": 123,
  "compilerRevision": "REVISION"
}
```

Possible outcomes are `completed`, `rejected`, `runtime_error`, `timed_out`,
`output_limit`, and `compiler_failure`. The service limits combined program
output to 32 KiB and execution to 1.5 seconds. API throttling can return HTTP
429. Malformed input uses 400, oversized source uses 413, and service faults use
500.

`log(value)` writes to `stderr`, so a successful program commonly has empty
`stdout`. Preserve the distinction between program output, compiler
diagnostics, and transport errors. Include `compilerRevision` when a result may
depend on compiler freshness.

The compiler revision may lag the public language capsule. A
`limit.unsupported-syntax` result can therefore mean that a documented facility
has not reached the deployed compiler. Report that compatibility gap; do not
rewrite the language explanation to match an older service revision.

The endpoint currently has no authentication layer. Do not add credentials or
send repository content, secrets, or unrelated user data.
